USER_LIST_FILE = "users_list.txt"

users = {
    "Sham": {
        "password": "sam123",
        "contact": "9827098765",
        "branch": "CSE-IOT",
        "section": "A",
        "course": "B.Tech"
    },
    "ram": {
        "password": "ram123",
        "contact": "9837785124",
        "branch": "CSE",
        "section": "B",
        "course": "B.Tech"
    }
}

def export_to_txt(users_dict):
    try:
        with open(USER_LIST_FILE, "w") as f:
            f.write("List of Registered Users......\n\n")
            if not users_dict:
                f.write("No users registered yet.")
                return
                
            for username, details in users_dict.items():
                f.write(f"Username: {username}||")
                f.write(f"  Contact: {details.get('contact', 'N/A')}||")
                f.write(f"  Branch: {details.get('branch', 'N/A')}||")
                f.write(f"  Course: {details.get('course', 'N/A')}\n")
    except IOError:
        print(f"Warning: Could not write to {USER_LIST_FILE}")

def register_user(username, password, contact, branch, section, course):
    global users
    if username in users:
        return False, "Already registered, please login."

    users[username] = {
        "password": password,
        "contact": contact,
        "branch": branch,
        "section": section,
        "course": course
    }
    export_to_txt(users)
    return True, "Successfully registered and logged in!"

def login_user(username, password):
    global users
    if username not in users:
        return False, "Not registered. Please register first."
    
    if users[username]["password"] == password:
        return True, "Login successful!"
    else:
        return False, "Wrong password."

def get_profile(username):
    global users
    return users.get(username) 

def update_profile(username, field_to_update, new_value):
    global users
    if username in users:
        users[username][field_to_update] = new_value
        if field_to_update in ['contact', 'branch', 'course']:
             export_to_txt(users)
        return True, f"{field_to_update.capitalize()} updated successfully!"
    return False, "User not found."

def update_username(old_username, new_username):
    global users
    if new_username in users:
        return False, "Username already taken."
    
    user_data = users.pop(old_username)
    users[new_username] = user_data
    export_to_txt(users)
    return True, "Username updated successfully!"

export_to_txt(users)

