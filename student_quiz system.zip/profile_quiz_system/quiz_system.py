import random

SCORE_FILE = "quiz_scores.txt"

QUESTIONS_BANK = [
    {
        "question": "What does 'AI' stand for?",
        "options": [
            "A. Automated Intelligence",
            "B. Artificial Intelligence",
            "C. Algorithmic Integration",
            "D. Advanced Internet"
        ],
        "answer": "B"
    },
    {
        "question": "Which programming language is commonly used for Machine Learning?",
        "options": [
            "A. Java",
            "B. C#",
            "C. Python",
            "D. PHP"
        ],
        "answer": "C"
    },
    {
        "question": "What is 'CPU' short for?",
        "options": [
            "A. Central Processing Unit",
            "B. Computer Personal Unit",
            "C. Central Program Utility",
            "D. Core Processing Unit"
        ],
        "answer": "A"
    },
    {
        "question": "What does 'RAM' stand for in computing?",
        "options": [
            "A. Read Access Memory",
            "B. Random Access Memory",
            "C. Run Application Module",
            "D. Real-time Access Memory"
        ],
        "answer": "B"
    },
    {
        "question": "Which of these is NOT a web browser?",
        "options": [
            "A. Google Chrome",
            "B. Microsoft Word",
            "C. Mozilla Firefox",
            "D. Apple Safari"
        ],
        "answer": "B"
    }
]

def save_score(username, score):
    try:
        with open(SCORE_FILE, "a") as f:
            f.write(f"Username: {username}, Score: {score}/20\n")
    except IOError:
        print(f"Error saving score to {SCORE_FILE}")

def get_last_score(username):
    try:
        with open(SCORE_FILE, "r") as f:
            lines = f.readlines()
        
        user_score = "No score on record."
        search_key = f"Username: {username}"
        
        for line in reversed(lines):
            if line.startswith(search_key):
                score_part = line.split(", ")[1].strip()
                user_score = score_part
                break
        return user_score
    except FileNotFoundError:
        return "No score on record."
    except IOError:
        return "Could not read score file."

def run_quiz(username):
    print("Welcome to the Quiz!........")
    print("You will be asked 5 questions. Each correct answer is worth 4 points.")
    
    questions_to_ask = QUESTIONS_BANK[:]
    random.shuffle(questions_to_ask)
    
    score = 0
    question_number = 1
    
    for item in questions_to_ask:
        print(f"Question {question_number}: {item['question']}")
        for option in item['options']:
            print(option)
        
        answer = input("Enter your choice (A, B, C, or D): ").upper()
        
        if answer == item['answer']:
            print("Correct!")
            score += 4
        else:
            print(f"Wrong. The correct answer was {item['answer']}.")
        
        question_number += 1
        
    print(f"Quiz Finished!........")
    print(f"Username: {username}")
    print(f"Your final score is: {score}/20")
    
    save_score(username, score)

