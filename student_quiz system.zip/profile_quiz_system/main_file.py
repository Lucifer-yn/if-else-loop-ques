import user_db as db
import quiz_system as quiz

logged = False
current_user = None

def register():
    global logged, current_user
    print("Registration......")
    username = input("Enter username: ")
    password = input("Enter password: ")
    contact = input("Enter contact number: ")
    branch = input("Enter branch: ")
    section = input("Enter section: ")
    course = input("Enter course: ")

    success, message = db.register_user(username, password, contact, branch, section, course)
    print(message)
    
    if success:
        logged = True
        current_user = username

def login():
    global logged, current_user
    print("Login......")
    username = input("Enter username: ")
    password = input("Enter password: ")

    success, message = db.login_user(username, password)
    print(message)

    if success:
        logged = True
        current_user = username
        show_profile()

def show_profile():
    global logged, current_user
    print("Show Profile......")
    if not logged or not current_user:
        print("Please login first.")
        return

    profile = db.get_profile(current_user)
    if profile:
        print(f"Username: {current_user}")
        print(f"Password: {'*' * len(profile.get('password', ''))}")
        print(f"Contact No.: {profile.get('contact', 'N/A')}")
        print(f"Branch: {profile.get('branch', 'N/A')}")
        print(f"Section: {profile.get('section', 'N/A')}")
        print(f"Course: {profile.get('course', 'N/A')}")
        
        last_score = quiz.get_last_score(current_user)
        print(f"Last Quiz Score: {last_score}")
        
        take_quiz = input("Do you want to take the quiz now? (y/n): ").lower()
        if take_quiz == 'y':
            quiz.run_quiz(current_user)
    else:
        print("Error: Could not retrieve profile.")

def update_profile():
    global logged, current_user
    print("Update Profile......")
    if not logged or not current_user:
        print("Please login first.")
        return

    choice = input("""Choose an option:
    1 - Edit username
    2 - Edit password
    3 - Edit contact number
    4. - Edit branch
    5 - Edit section
    6 - Edit course
    Enter choice: """)

    if choice == "1":
        new_username = input("Enter new username: ")
        success, message = db.update_username(current_user, new_username)
        print(message)
        if success:
            current_user = new_username
    
    elif choice == "2":
        new_value = input("Enter new password: ")
        success, message = db.update_profile(current_user, "password", new_value)
        print(message)
        
    elif choice == "3":
        new_value = input("Enter new contact number: ")
        success, message = db.update_profile(current_user, "contact", new_value)
        print(message)

    elif choice == "4":
        new_value = input("Enter new branch: ")
        success, message = db.update_profile(current_user, "branch", new_value)
        print(message)

    elif choice == "5":
        new_value = input("Enter new section: ")
        success, message = db.update_profile(current_user, "section", new_value)
        print(message)

    elif choice == "6":
        new_value = input("Enter new course: ")
        success, message = db.update_profile(current_user, "course", new_value)
        print(message)

    else:
        print("Invalid option.")

def logout():
    global logged, current_user
    if logged:
        print(f"\n{current_user}, you are logged out.")
        logged = False
        current_user = None
    else:
        print("No user is currently logged in.")

def terminate():
    print("Thank You. Goodbye!")
    exit()

def main():
    while True:
        print("Welcome to the Site.....")
        response = input("""Choose an option:
    1 - Register
    2 - Login
    3 - Show Profile
    4. - Update Profile
    5 - Logout
    6 - Terminate
    Select option (1/2/3/4/5/6): """)

        if response == "1":
            register()
        elif response == "2":
            login()
        elif response == "3":
            show_profile()
        elif response == "4":
            update_profile()
        elif response == "5":
            logout()
        elif response == "6":
            terminate()
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()

